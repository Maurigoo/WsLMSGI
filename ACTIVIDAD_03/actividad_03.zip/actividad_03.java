
public class actividad_03 {

	public static void main(String[] args) {
		
		
		//Conversion de enteros a flotante
		
		/*
		 * No hemos perdido informacion en este caso
		 */
		
		   int entero = 45;  
	       float numeroFloat = entero;  
	       System.out.println(numeroFloat); 
	        
	       
	       
	       //Conversión de Flotantes a Enteros
	       
	       /*
	        * Si es necesario hacer "casting" y se pierde informacion
	        */
	       
	       float numeroFloat1 =  24.89F;
	       int numeroEntero1 = (int)numeroFloat1;
	       System.out.println(numeroEntero1);
	        
	       
	       
	       
	       //Conversión de Double a Enteros
	       
	      /*
	       * Si es necesario hacer "casting" y se pierde informacion
	       */
	       
	       double numeroDouble = 78.56;
	       int numeroEntero2 = (int)numeroDouble;
	       System.out.println(numeroEntero2);
	        
	       
	       
	       
	       //Conversión de Enteros a Double:
	       
	       /*
	        * No es necesario hacer casting y no se pierde informacion
	        */
	       
	       int Entero3 = 60;
	       double numeroDouble1 = Entero3;
	       System.out.println(numeroDouble1);
	        
	       
	       
	       //Conversión de Caracteres (char) a Enteros
	       
	       /*
	        * Si se puede hacer la operacion y lo representa en codigo ASCII
	        */
	       
	       char variableChar = 'F';
	       int numeroEntero4 = variableChar;
	       System.out.println(numeroEntero4);
	       
	       
	       
	       //Conversión de Enteros a Caracteres:
	       
	       /*
	        * Si se puede hacer la operacion y lo representa en codigo ASCII
	        */
	       
	       int numeroEntero5 = 70;
	       char variableChar1 = (char)numeroEntero5;
	       System.out.println(variableChar1);
	       
	       
	       
	       //Conversión de Cadenas a Entero:
	       
	       /*
	        * No se puede hacer la operacion
	        */
	       
	       String variableCadena = "Hola Mundo";
	       int numeroEntero6 = (String)variableCadena;
	       System.out.println(numeroEntero6);
	       
	       
	       //Conversión de Cadenas(String) a Caracteres (char)
	       
	       /*
	        * No se puede hacer la operacion
	        */
	       
	       String variableCadena1 = "Holaaa";
	       char variableChar2 = (String)variableCadena1;
	       System.out.println(variableChar2);
	        

	}

}
